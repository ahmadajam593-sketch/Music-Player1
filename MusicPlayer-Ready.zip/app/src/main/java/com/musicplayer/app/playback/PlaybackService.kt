package com.musicplayer.app.playback

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import com.musicplayer.app.MusicApp
import com.musicplayer.app.data.MusicRepository
import com.musicplayer.app.data.PlaybackStateStore
import com.musicplayer.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Owns the ExoPlayer + MediaSession. Media3 automatically provides the persistent media
 * notification, lock screen controls, Bluetooth / headset button handling and audio focus.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer
    private lateinit var store: PlaybackStateStore
    private lateinit var repo: MusicRepository
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var progressJob: Job? = null
    private var lastCountedId: String? = null

    override fun onCreate() {
        super.onCreate()
        val container = (application as MusicApp).container
        store = container.playbackStore
        repo = container.repository

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true) // pause when headphones are unplugged
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(playerListener)

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(openApp)
            .setCallback(sessionCallback)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Keep playing if music is active; otherwise shut down.
        val p = mediaSession?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        saveProgress()
        progressJob?.cancel()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        scope.cancel()
        super.onDestroy()
    }

    // Lets a headset button / Bluetooth device resume the last queue even after the app was killed.
    private val sessionCallback = object : MediaSession.Callback {
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val future = SettableFuture.create<MediaSession.MediaItemsWithStartPosition>()
            scope.launch {
                try {
                    val result = withContext(Dispatchers.IO) {
                        val saved = store.load() ?: return@withContext null
                        val songs = repo.getSongsByIds(saved.ids)
                        if (songs.isEmpty()) return@withContext null
                        val idx = songs.indexOfFirst { it.id == saved.currentId }
                        MediaSession.MediaItemsWithStartPosition(
                            songs.map { it.toMediaItem() },
                            idx.coerceAtLeast(0),
                            if (idx >= 0) saved.positionMs else 0L,
                        )
                    }
                    if (result == null) future.setException(UnsupportedOperationException("Nothing to resume"))
                    else future.set(result)
                } catch (e: Exception) {
                    future.setException(e)
                }
            }
            return future
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onTimelineChanged(timeline: Timeline, reason: Int) = saveQueue()

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            lastCountedId = null
            if (player.playWhenReady) countPlayIfNew()
            saveProgress()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                countPlayIfNew()
                startProgressSaver()
            } else {
                progressJob?.cancel()
                saveProgress()
            }
        }

        override fun onRepeatModeChanged(repeatMode: Int) = saveModes()
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) = saveModes()

        override fun onPlayerError(error: PlaybackException) {
            // Unplayable / missing file: skip to the next track instead of getting stuck.
            if (player.hasNextMediaItem()) {
                player.seekToNextMediaItem()
                player.prepare()
                player.play()
            }
        }
    }

    private fun countPlayIfNew() {
        val id = player.currentMediaItem?.mediaId ?: return
        if (id == lastCountedId) return
        lastCountedId = id
        val songId = id.toLongOrNull() ?: return
        scope.launch(Dispatchers.IO) { runCatching { repo.recordPlay(songId) } }
    }

    private fun startProgressSaver() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                delay(5_000)
                saveProgress()
            }
        }
    }

    private fun saveQueue() {
        if (player.mediaItemCount == 0) return
        val ids = (0 until player.mediaItemCount).mapNotNull { player.getMediaItemAt(it).mediaId.toLongOrNull() }
        store.saveQueue(ids)
    }

    private fun saveProgress() {
        val id = player.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        store.saveProgress(id, player.currentPosition.coerceAtLeast(0))
    }

    private fun saveModes() = store.saveModes(player.repeatMode, player.shuffleModeEnabled)
}

package com.musicplayer.app.data

import android.content.Context

data class SavedPlayback(
    val ids: List<Long>,
    val currentId: Long,
    val positionMs: Long,
    val repeat: Int,
    val shuffle: Boolean,
)

/** Persists the playback queue and position so they survive process death / reboot. */
class PlaybackStateStore(context: Context) {
    private val prefs = context.getSharedPreferences("playback_state", Context.MODE_PRIVATE)

    fun saveQueue(ids: List<Long>) {
        prefs.edit().putString("ids", ids.joinToString(",")).apply()
    }

    fun saveProgress(currentId: Long, positionMs: Long) {
        prefs.edit().putLong("cur", currentId).putLong("pos", positionMs).apply()
    }

    fun saveModes(repeat: Int, shuffle: Boolean) {
        prefs.edit().putInt("repeat", repeat).putBoolean("shuffle", shuffle).apply()
    }

    fun load(): SavedPlayback? {
        val raw = prefs.getString("ids", null)?.takeIf { it.isNotEmpty() } ?: return null
        val ids = raw.split(',').mapNotNull { it.toLongOrNull() }
        if (ids.isEmpty()) return null
        return SavedPlayback(
            ids = ids,
            currentId = prefs.getLong("cur", ids.first()),
            positionMs = prefs.getLong("pos", 0L),
            repeat = prefs.getInt("repeat", 0),
            shuffle = prefs.getBoolean("shuffle", false),
        )
    }
}

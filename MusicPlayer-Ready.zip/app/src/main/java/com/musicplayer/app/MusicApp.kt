package com.musicplayer.app

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.musicplayer.app.data.AppDatabase
import com.musicplayer.app.data.MusicRepository
import com.musicplayer.app.data.PlaybackStateStore

class MusicApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

class AppContainer(context: Context) {
    val database: AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "music.db").build()
    val repository = MusicRepository(context.applicationContext, database)
    val playbackStore = PlaybackStateStore(context.applicationContext)
}

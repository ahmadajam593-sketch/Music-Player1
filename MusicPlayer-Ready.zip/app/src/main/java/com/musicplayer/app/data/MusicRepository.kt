package com.musicplayer.app.data

import android.content.Context
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context, private val db: AppDatabase) {
    private val songDao = db.songDao()
    private val playlistDao = db.playlistDao()
    private val historyDao = db.historyDao()
    private val scanner = MediaScanner(context)
    private val scanMutex = Mutex()

    val songs: Flow<List<Song>> = songDao.observeAll()
    val recent: Flow<List<Song>> = songDao.observeRecent()
    val mostPlayed: Flow<List<Song>> = songDao.observeMostPlayed()
    val favorites: Flow<List<Song>> = songDao.observeFavorites()
    val playlists: Flow<List<PlaylistWithCount>> = playlistDao.observeAll()

    /** Scans MediaStore and syncs the database. Returns the number of songs found, or -1 on failure. */
    suspend fun scanLibrary(): Int = scanMutex.withLock {
        withContext(Dispatchers.IO) {
            val found = scanner.scan() ?: return@withContext -1
            val foundIds = found.mapTo(HashSet()) { it.id }
            db.withTransaction {
                val removed = songDao.getAllIds().filter { it !in foundIds }
                found.chunked(500).forEach { songDao.upsertAll(it) }
                removed.chunked(500).forEach { songDao.deleteByIds(it) }
            }
            found.size
        }
    }

    /** Emits whenever the device's audio library changes (new / deleted files). */
    fun mediaChanges(): Flow<Unit> = callbackFlow {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) { trySend(Unit) }
        }
        context.contentResolver.registerContentObserver(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer
        )
        awaitClose { context.contentResolver.unregisterContentObserver(observer) }
    }

    /** Returns songs in the same order as [ids]; missing songs are skipped. */
    suspend fun getSongsByIds(ids: List<Long>): List<Song> {
        val map = ids.distinct().chunked(500).flatMap { songDao.getByIds(it) }.associateBy { it.id }
        return ids.mapNotNull { map[it] }
    }

    suspend fun toggleFavorite(song: Song) = db.withTransaction {
        songDao.ensureStats(SongStatsEntity(song.id))
        songDao.setFavorite(song.id, !song.favorite)
    }

    suspend fun setCustomArt(songId: Long, uri: String?) = db.withTransaction {
        songDao.ensureStats(SongStatsEntity(songId))
        songDao.setCustomArt(songId, uri)
    }

    suspend fun recordPlay(songId: Long) = db.withTransaction {
        val now = System.currentTimeMillis()
        songDao.ensureStats(SongStatsEntity(songId))
        songDao.incrementPlay(songId, now)
        historyDao.insert(HistoryEntity(songId = songId, playedAt = now))
        historyDao.prune()
    }

    // ---- Playlists ----
    suspend fun createPlaylist(name: String): Long =
        playlistDao.insert(PlaylistEntity(name = name.trim(), createdAt = System.currentTimeMillis()))

    suspend fun renamePlaylist(id: Long, name: String) = playlistDao.rename(id, name.trim())
    suspend fun deletePlaylist(id: Long) = playlistDao.delete(id)
    fun playlistSongs(id: Long): Flow<List<Song>> = playlistDao.observeSongs(id)

    suspend fun addToPlaylist(playlistId: Long, songIds: List<Long>) = db.withTransaction {
        var pos = playlistDao.maxPosition(playlistId)
        songIds.forEach { playlistDao.insertLink(PlaylistSongEntity(playlistId, it, ++pos)) }
    }

    suspend fun removeFromPlaylist(playlistId: Long, songId: Long) = playlistDao.removeLink(playlistId, songId)

    suspend fun reorderPlaylist(playlistId: Long, orderedSongIds: List<Long>) = db.withTransaction {
        orderedSongIds.forEachIndexed { i, id -> playlistDao.setPosition(playlistId, id, i) }
    }
}

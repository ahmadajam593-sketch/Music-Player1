package com.musicplayer.app.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "songs", indices = [Index("albumId"), Index("folder")])
data class SongEntity(
    @PrimaryKey val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val path: String,
    val folder: String,
    val dateAdded: Long,
    val mimeType: String,
    val sizeBytes: Long,
    val trackNumber: Int,
    val uri: String,
)

/** User data kept separately so rescans never wipe favorites / play counts. */
@Entity(tableName = "song_stats")
data class SongStatsEntity(
    @PrimaryKey val songId: Long,
    val favorite: Boolean = false,
    val playCount: Int = 0,
    val lastPlayed: Long = 0,
    val customArtUri: String? = null,
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
)

@Entity(
    tableName = "playlist_songs",
    primaryKeys = ["playlistId", "songId"],
    indices = [Index("songId")],
    foreignKeys = [ForeignKey(
        entity = PlaylistEntity::class,
        parentColumns = ["id"],
        childColumns = ["playlistId"],
        onDelete = ForeignKey.CASCADE,
    )],
)
data class PlaylistSongEntity(val playlistId: Long, val songId: Long, val position: Int)

@Entity(tableName = "history", indices = [Index("songId"), Index("playedAt")])
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val songId: Long,
    val playedAt: Long,
)

data class PlaylistWithCount(val id: Long, val name: String, val createdAt: Long, val songCount: Int)

/** Song joined with its user stats. This is the model the UI works with. */
data class Song(
    @Embedded val entity: SongEntity,
    val favorite: Boolean,
    val playCount: Int,
    val lastPlayed: Long,
    val customArtUri: String?,
) {
    val id: Long get() = entity.id
    val title: String get() = entity.title
    val artist: String get() = entity.artist
    val album: String get() = entity.album
    val albumId: Long get() = entity.albumId
    val durationMs: Long get() = entity.durationMs
    val uri: String get() = entity.uri
    val path: String get() = entity.path
    val folder: String get() = entity.folder
}

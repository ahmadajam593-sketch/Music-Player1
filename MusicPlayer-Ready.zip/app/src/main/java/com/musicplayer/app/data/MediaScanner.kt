package com.musicplayer.app.data

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import android.util.Log

/** Reads real audio files from MediaStore (MP3, FLAC, WAV, AAC, OGG, M4A, ...). */
class MediaScanner(private val context: Context) {

    /** Returns null if the scan failed (e.g. permission missing) so callers never wipe the library. */
    fun scan(minDurationMs: Long = 15_000): List<SongEntity>? {
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.TRACK,
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        val result = ArrayList<SongEntity>()
        try {
            context.contentResolver.query(
                collection, projection, selection, arrayOf(minDurationMs.toString()), null
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val iAdded = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val iMime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val path = c.getString(iData).orEmpty()
                    result += SongEntity(
                        id = id,
                        title = c.getString(iTitle)?.takeIf { it.isNotBlank() } ?: path.substringAfterLast('/'),
                        artist = clean(c.getString(iArtist), "Unknown artist"),
                        album = clean(c.getString(iAlbum), "Unknown album"),
                        albumId = c.getLong(iAlbumId),
                        durationMs = c.getLong(iDur),
                        path = path,
                        folder = path.substringBeforeLast('/', ""),
                        dateAdded = c.getLong(iAdded),
                        mimeType = c.getString(iMime).orEmpty(),
                        sizeBytes = c.getLong(iSize),
                        trackNumber = c.getInt(iTrack) % 1000,
                        uri = ContentUris.withAppendedId(collection, id).toString(),
                    )
                }
            } ?: return null
        } catch (e: Exception) {
            Log.e("MediaScanner", "Scan failed", e)
            return null
        }
        return result
    }

    private fun clean(value: String?, fallback: String) =
        value?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: fallback
}

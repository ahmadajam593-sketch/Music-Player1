# Music Player (Android)

Kotlin · Jetpack Compose · Media3 ExoPlayer · Room · MediaStore. Module name: `app`.

## Build
GitHub Actions (`.github/workflows/android.yml`) builds `./gradlew assembleDebug` on every push.
Download the APK from the run's **Artifacts** (`MusicPlayer-debug-apk`).
Locally: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`.
